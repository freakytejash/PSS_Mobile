package com.example.pssmobile.utils

object Singleton {
   lateinit var zohoCreatorUserId: String
}