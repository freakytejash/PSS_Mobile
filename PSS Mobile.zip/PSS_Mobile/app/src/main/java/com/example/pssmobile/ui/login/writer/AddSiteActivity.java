package com.example.pssmobile.ui.login.writer;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;

import com.example.pssmobile.R;
import com.example.pssmobile.data.model.AddSiteRequest;
import com.example.pssmobile.databinding.ActivityAddSiteBinding;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class AddSiteActivity extends AppCompatActivity {
    private ActivityAddSiteBinding binding;
    RadioButton  invoiceRadioBtn;
    private static final int PICKFILE_RESULT_CODE = 1;
    String encodeFileToBase64Binary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddSiteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("file/*");
                startActivityForResult(intent,PICKFILE_RESULT_CODE);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case PICKFILE_RESULT_CODE:
                if (resultCode == RESULT_OK) {
                    String filePath = data.getData().getPath();
                    binding.tvFilePath.setText(filePath);
                    File dir = Environment.getExternalStorageDirectory();
                    File yourFile = new File(dir, filePath );
                    encodeFileToBase64Binary = encodeFileToBase64Binary(yourFile);
                    Log.e("file",encodeFileToBase64Binary);

                }
                break;

        }
    }

    private String encodeFileToBase64Binary(File yourFile) {
        int size = (int) yourFile.length();
        byte[] bytes = new byte[size];
        try {
            BufferedInputStream buf = new BufferedInputStream(new FileInputStream(yourFile));
            buf.read(bytes, 0, bytes.length);
            buf.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        String encoded = Base64.encodeToString(bytes,Base64.NO_WRAP);
        Log.e("file",encoded);
        Log.d("file",encoded);
        Log.i("file",encoded);
        Log.v("file",encoded);

        return encoded;
    }



    public void addSite(){
        AddSiteRequest request = new AddSiteRequest();
        request.siteName = binding.etSiteName.getText().toString().trim();
        request.siteAddress = binding.etSiteAddress.getText().toString().trim();
        request.suburb = binding.etSuburb.getText().toString().trim();
        request.postCode = binding.etPostCode.getText().toString().trim();
        int invoiceScheduleId = binding.radioGroupInvoiceSchedule.getCheckedRadioButtonId();
        invoiceRadioBtn = findViewById(invoiceScheduleId);
        request.invoicingSchedule = invoiceRadioBtn.getText().toString();
        request.sitebriefing.url = binding.etSiteBriefing.getText().toString().trim();
        request.active= binding.checkBoxIsActive.isChecked();
        request.keys = binding.etPssKey.getText().toString().trim();
        //request.
    }
}