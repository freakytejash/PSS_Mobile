import com.google.gson.annotations.SerializedName

data class Data1 (

	@SerializedName("ID") val iD : String
)