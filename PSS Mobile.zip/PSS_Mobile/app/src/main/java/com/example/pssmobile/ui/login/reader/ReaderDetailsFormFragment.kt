package com.example.pssmobile.ui.login.reader

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.pssmobile.R
import com.example.pssmobile.databinding.FragmentReaderDetailsFormBinding
import com.example.pssmobile.repository.ReaderRepository
import com.example.pssmobile.ui.login.base.BaseFragment

class ReaderDetailsFormFragment : BaseFragment<ReaderViewModel, FragmentReaderDetailsFormBinding, ReaderRepository>() {


    override fun getViewModel(): Class<ReaderViewModel> {
        TODO("Not yet implemented")
    }

    override fun getFragmentBinding(inflater: LayoutInflater, container: ViewGroup?): FragmentReaderDetailsFormBinding {
        TODO("Not yet implemented")
    }

    override fun getFragmentRepository(): ReaderRepository {
        TODO("Not yet implemented")
    }

}