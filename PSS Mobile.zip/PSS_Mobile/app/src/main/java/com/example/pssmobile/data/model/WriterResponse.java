package com.example.pssmobile.data.model;



public class WriterResponse {
    private Getters[] Checkpoint_Database;

    public Getters[] getAndroid() {
        return this.Checkpoint_Database;
    }
}
