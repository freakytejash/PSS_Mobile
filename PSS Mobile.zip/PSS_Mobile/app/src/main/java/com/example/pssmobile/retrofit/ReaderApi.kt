package com.example.pssmobile.retrofit
import retrofit2.http.GET

interface ReaderApi {

    /*@GET("PatrolReport/GetJobsList?zohoCreatorUserName=Mobile%201")
    suspend fun getZohoCreatorReaderResponse(): ZohoCreatorResponse*/
}