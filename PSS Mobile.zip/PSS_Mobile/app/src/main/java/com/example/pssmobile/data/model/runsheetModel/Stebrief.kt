import com.google.gson.annotations.SerializedName

data class Stebrief (

	@SerializedName("url") val url : String
)